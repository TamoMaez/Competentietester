package controller.question;

import controller.AbstractTestMouseAdapter;
import view.panels.QuestionDetailPanel;
import domain.facade.AdministratorFacade;

public class QuestionEditAction extends AbstractTestMouseAdapter {

	public QuestionEditAction(AdministratorFacade service) {
		super(service);
	}

	public void setDetailPanel(QuestionDetailPanel questionDetailPanel) {
		// TODO Auto-generated method stub
		
	}

}
