package controller;

import java.awt.event.ActionEvent;

import domain.facade.AdministratorFacade;

public class NewFileAction extends AbstractTestAction {

	private static final long serialVersionUID = 1L;

	public NewFileAction(AdministratorFacade service) {
		super(service, "New");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
