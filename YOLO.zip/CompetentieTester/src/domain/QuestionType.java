package domain;

public enum QuestionType {
	MC,
	YN;
}
