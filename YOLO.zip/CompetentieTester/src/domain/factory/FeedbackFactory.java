package domain.factory;

public class FeedbackFactory {

}
