package domain.scoreCalculatorStrategy;

public class TimeScoreCalculator {

}
