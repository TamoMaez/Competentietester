package domain.scoreCalculatorStrategy;

import java.util.List;

import domain.Answer;


public class SumScoreCalculator implements ScoreCalculator {

	@Override
	public int calculateScore(List<Answer> answers) {
		// TODO Auto-generated method stub
		return 0;
	}

}
