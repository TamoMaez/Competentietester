package domain.scoreCalculatorStrategy;

import java.util.List;

import domain.Answer;


public class GisScoreCalculator implements ScoreCalculator {

	@Override
	public int calculateScore(List<Answer> answers) {
		// TODO Auto-generated method stub
		return 0;
	}

}
