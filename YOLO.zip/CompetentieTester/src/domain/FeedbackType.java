package domain;

public enum FeedbackType {
	SCORE, TEXT
}
